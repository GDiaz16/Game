<?xml version="1.0" encoding="UTF-8"?>
<tileset version="1.2" tiledversion="1.3.5" name="angle" tilewidth="256" tileheight="512" tilecount="3" columns="0">
 <grid orientation="orthogonal" width="1" height="1"/>
 <tile id="0">
  <image width="256" height="512" source="../../../Assets/Isometric-Assets/kenney_prototypePack_2.3/Angle/column_N.png"/>
 </tile>
 <tile id="1">
  <image width="256" height="512" source="../../../Assets/Isometric-Assets/kenney_prototypePack_2.3/Angle/doorClosed_E.png"/>
 </tile>
 <tile id="2">
  <image width="256" height="512" source="../../../Assets/Isometric-Assets/kenney_prototypePack_2.3/Angle/wall_W.png"/>
 </tile>
</tileset>
