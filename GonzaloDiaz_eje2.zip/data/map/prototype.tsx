<?xml version="1.0" encoding="UTF-8"?>
<tileset version="1.2" tiledversion="1.3.5" name="prototype-min" tilewidth="256" tileheight="512" tilecount="242" columns="22">
 <image source="../img/map/prototype-sheet.png" width="5632" height="5632"/>
 <tile id="4">
  <animation>
   <frame tileid="1" duration="500"/>
   <frame tileid="4" duration="500"/>
  </animation>
 </tile>
 <tile id="5">
  <animation>
   <frame tileid="3" duration="500"/>
   <frame tileid="5" duration="500"/>
  </animation>
 </tile>
 <tile id="6">
  <animation>
   <frame tileid="0" duration="500"/>
   <frame tileid="6" duration="500"/>
  </animation>
 </tile>
 <tile id="7">
  <animation>
   <frame tileid="2" duration="500"/>
   <frame tileid="7" duration="500"/>
  </animation>
 </tile>
</tileset>
