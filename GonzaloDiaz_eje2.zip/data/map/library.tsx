<?xml version="1.0" encoding="UTF-8"?>
<tileset version="1.2" tiledversion="1.3.5" name="library" tilewidth="256" tileheight="512" tilecount="153" columns="17">
 <image source="../img/map/library-sheet.png" width="4352" height="4608"/>
</tileset>
