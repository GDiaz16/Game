<?xml version="1.0" encoding="UTF-8"?>
<tileset version="1.2" tiledversion="1.3.5" name="dungeon-min" tilewidth="256" tileheight="512" tilecount="288" columns="24">
 <image source="../img/map/dungeon-sheet.png" width="6144" height="6144"/>
</tileset>
