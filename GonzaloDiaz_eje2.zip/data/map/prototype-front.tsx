<?xml version="1.0" encoding="UTF-8"?>
<tileset version="1.2" tiledversion="1.3.5" name="prototype-front" tilewidth="256" tileheight="512" tilecount="242" columns="22">
 <image source="../img/map/prototype-front.png" width="5632" height="5632"/>
 <tile id="21">
  <animation>
   <frame tileid="0" duration="500"/>
   <frame tileid="2" duration="500"/>
   <frame tileid="1" duration="500"/>
  </animation>
 </tile>
</tileset>
