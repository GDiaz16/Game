function hide(){
    document.getElementById("home-screen").style.display = "none";
}

function show(){
    document.getElementById("home-screen").style.display = "block";

}
